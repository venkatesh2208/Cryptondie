from flask_sqlalchemy import SQLAlchemy

database = SQLAlchemy()